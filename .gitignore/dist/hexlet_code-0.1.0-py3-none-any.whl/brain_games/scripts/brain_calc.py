#!/usr/bin/env python

from brain_games.logic import engine_games
from brain_games.games import calc


def main():
    engine_games.run(calc)


if __name__ == '__main__':
    main()
