#!/usr/bin/env python

from brain_games.games import even
from brain_games import engine_games


def main():
    engine_games.run(even)


if __name__ == '__main__':
    main()
