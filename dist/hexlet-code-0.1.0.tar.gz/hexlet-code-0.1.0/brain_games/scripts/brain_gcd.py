#!/usr/bin/env python

from brain_games.games.gcd import find_gcd


def main():
    print("Welcome to the Brain Games!")
    find_gcd()


if __name__ == '__main__':
    main()
