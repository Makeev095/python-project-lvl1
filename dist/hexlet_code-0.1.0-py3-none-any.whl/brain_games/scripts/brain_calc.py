#!/usr/bin/env python

from brain_games.calc import calculator

def main():
    print("Welcome to the Brain Games!")
    calculator()



if __name__ == '__main__':
    main()