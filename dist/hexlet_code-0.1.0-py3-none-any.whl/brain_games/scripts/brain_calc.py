#!/usr/bin/env python

from brain_games.games.calc import calc_operations


def main():
    print("Welcome to the Brain Games!")
    calc_operations()


if __name__ == '__main__':
    main()
