#!/usr/bin/env python

from brain_games.games import prime
from brain_games import engine_games


def main():
    engine_games.run(prime)


if __name__ == '__main__':
    main()
